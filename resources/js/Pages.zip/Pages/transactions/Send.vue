<template>
  <div class="flex h-screen bg-gray-100">
    <Sidebar />
    <div class="flex flex-col flex-1">
      <Navbar :name="user.name" :avatar="user.avatar" />
      <div class="flex-1 p-6 overflow-auto">
        <div class="max-w-2xl p-6 mx-auto bg-white rounded-lg shadow-md">
          <h1 class="mb-6 text-3xl font-bold text-gray-800">Envoyer</h1>
          <div
            v-if="
              page.props.errors.recipient ||
              page.props.errors.phone_receiver ||
              page.props.errors.amount ||
              page.props.errors.description
            "
            class="p-4 mb-6 text-red-700 bg-red-100 border border-red-400 rounded"
          >
            {{
              page.props.errors.phone_receiver ||
              page.props.errors.amount ||
              page.props.errors.description
            }}
          </div>
          <form @submit.prevent="handleSubmit" class="space-y-6">
            <!-- Recipient -->
            <div>
              <label class="block mb-2 text-sm font-medium text-gray-700">
                Destinataire
              </label>
              <input
                v-model="form.phone_receiver"
                type="text"
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <!-- Amount -->
            <div>
              <label class="block mb-2 text-sm font-medium text-gray-700">
                Montant
              </label>
              <input
                v-model="form.amount"
                type="number"
                step="0.01"
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <!-- Description -->
            <div>
              <label class="block mb-2 text-sm font-medium text-gray-700">
                Description
              </label>
              <textarea
                v-model="form.description"
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                rows="3"
              ></textarea>
            </div>

            <button
              type="submit"
              class="w-full py-2 font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700"
            >
              Envoyer
            </button>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>
<script setup lang="ts">
import { useForm, usePage } from "@inertiajs/vue3";
import Navbar from "../../components/layout/dashboard/Navbar.vue";
import Sidebar from "../../components/layout/dashboard/Sidebar.vue";

interface FormData {
  phone_receiver: string;
  amount: number;
  description?: string;
}
const page = usePage();
const user = page.props.auth.user.data;
const form = useForm({
  phone_receiver: "",
  amount: 0,
  description: "",
});

const handleSubmit = () => {
  form.post(
    "/transactions/send",

    {
      onSuccess: () => {
        form.reset();
      },
    }
  );
};
</script>
